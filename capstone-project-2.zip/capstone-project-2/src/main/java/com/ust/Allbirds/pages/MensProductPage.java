package com.ust.Allbirds.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class MensProductPage {
	WebDriver driver;

	public MensProductPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		// this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	}

	@FindBy(xpath = "(//span[@class='jsx-3492423137 jsx-2863553625 SizeButton-content'])[3]")
	public static WebElement size9;

	@FindBy(xpath = "(//span[@class='jsx-1643347871 Checkbox__checkmark'])[1]")
	public static WebElement bestforeveryday;

	@FindBy(xpath = "(//span[@class='jsx-1643347871 Checkbox__checkmark'])[6]")
	public static WebElement materiallightweight;

	@FindBy(css = ".jsx-512138434.ColorSwatch")
	public static WebElement hueblack;

	@FindBy(css = "button[aria-label='Add Size 9.5']")
	public static WebElement size9half;

	@FindBy(xpath = "(//span[@class='jsx-1643347871 Checkbox__checkmark'])[2]")
	public static WebElement bestforwarmweather;

	@FindBy(xpath = "(//span[@class='jsx-1643347871 Checkbox__checkmark'])[7]")
	public static WebElement materiallight;

	@FindBy(css = ".jsx-2002280460.ColorSwatch")
	public static WebElement hueblue;

	public void selectSingleFilter() {
		size9.click();
		bestforeveryday.click();
		materiallightweight.click();
		hueblack.click();
	}

	public void selectMultipleFilter() {
		size9.click();
		size9half.click();
		bestforeveryday.click();
		bestforwarmweather.click();
		materiallightweight.click();
		materiallight.click();
		hueblack.click();
		hueblue.click();
	}

	public void scrolldown() {
		JavascriptExecutor js = (JavascriptExecutor) driver;
		js.executeScript("window.scrollBy(0,450)", "");
	}

}
