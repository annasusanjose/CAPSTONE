package com.ust.Allbirds.pages;

import java.time.Duration;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class CartPage {
	WebDriver driver;

	public CartPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(css = ".jsx-1969544649.NumberStepper__button.NumberStepper__button--step-up")
	public static WebElement productincrement;

	@FindBy(css = ".jsx-1969544649.NumberStepper__button.NumberStepper__button--step-down")
	public static WebElement productdecrement;

	@FindBy(css = ".jsx-2418670298.CloseIcon.CloseIcon--hoverable")
	public static WebElement closecartbutton;

	@FindBy(css = ".jsx-20177884.CloseIcon.CloseIcon--hoverable")
	public static WebElement removeitembutton;

	@FindBy(css = "a[class='jsx-4080304301 Button Button--default Button--full-width Button--uppercase']")
	public static WebElement checkoutbutton;

	@FindBy(css = " .jsx-175512945.Drawer__header  .jsx-2224907785.jsx-3489369594.CartCount__icon text")
	public static WebElement cartquantity;

	@FindBy(xpath = "//span[@aria-label='Quantity']")
	public static WebElement cartquantity2;
	
	@FindBy(className = "CartEmptyState__heading")
	public static WebElement noitemincart;

	@FindBy(className = "Icon--HELP")
	public static WebElement helpicon;

	public void addProductCount() {
		productincrement.click();
	}

	public void removeProductCount() {
		productdecrement.click();
	}

	public void removeProductfromCart() {
		removeitembutton.click();
	}

	public void checkout() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		WebElement element = wait.until(ExpectedConditions.elementToBeClickable(checkoutbutton));
		element.click();
	}

	public void closeCartPage() {
		closecartbutton.click();
	}

	public int getItemQuantity() {
		String quantity1 = cartquantity.getText();
		return Integer.parseInt(quantity1);
	}

	public int getItemquantity2() {
		String quantity2 = cartquantity2.getText();
		return Integer.parseInt(quantity2);
	}

	public String verifyEmptyCart()
	{
		String errormsg = noitemincart.getText();
		return errormsg;
	}
	public boolean checkHelpIcon() {
		helpicon.isDisplayed();
		return true;
	}

}
