package com.ust.Allbirds.pages;

import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePage {
	WebDriver driver;
	JavascriptExecutor js;

	public HomePage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
		js = (JavascriptExecutor) driver;
		// this.wait = new WebDriverWait(driver, Duration.ofSeconds(10));
	}

	@FindBy(css = "div.Icon.Icon--USER")
	private static WebElement profileIcon;

	@FindBy(className = "CloseIcon--hoverable")
	public static WebElement closepopup;

	@FindBy(id = "EmailSignupModule__input")
	public static WebElement sendupdateemailfield;

	@FindBy(id = "EmailSignupModule__submit-button")
	public static WebElement sendupdateemailbutton;

	@FindBy(xpath = "(//h2[@class='jsx-2714253045 typography--secondary-heading'])[5]")
	public static WebElement sendupdatesuccessverify;

	@FindBy(xpath = "//div[@class='jsx-2224907785 jsx-3489369594 CartCount__icon']")
	public static WebElement cartbutton;

	@FindBy(xpath = "//img[@alt='Shop Flag - UK']")
	public static WebElement selectcountry;

	@FindBy(linkText = "ReRun")
	public static WebElement rerunpage;

	@FindBy(className = "Icon--ALLBIRDS_LOGO")
	public static WebElement allbirdshome;

	@FindBy(linkText = "Refer a Friend")
	public static WebElement refer;

	@FindBy(className = "SearchIcon__icon-search")
	public WebElement searchicon;

	
	@FindBy(linkText = "Returns/Exchanges")
	private WebElement exchange;


	public void scrollToGetUpdates(String email) {
		js.executeScript("window.scrollBy(0,1000)", "");
		sendupdateemailfield.sendKeys(email);
		sendupdateemailbutton.click();
	}

	public void clickProfileIcon() {
		profileIcon.click();
	}

	public String verifyGetUpdate() {
		String str = sendupdatesuccessverify.getText();
		return str;
	}

	public void scrollToChangeCountry() {
		js.executeScript("window.scrollBy(0,3500)", "");
		selectcountry.click();
	}

	public void navigatetoRerunPage() {
		rerunpage.click();
	}

	public void navigatetoAllbirdsHome() {
		allbirdshome.click();

	}

	public void clicksearchicon() {
		searchicon.click();
	}

	public void clickReferalLink() {
		js.executeScript("window.scrollBy(0,2500)", "");
		refer.click();
	}
	public void clickReturnLink() {
		js.executeScript("window.scrollBy(0,2500)", "");
		exchange.click();
	}

	public void cartbutton() {
		cartbutton.click();
		
	}


		
	}


