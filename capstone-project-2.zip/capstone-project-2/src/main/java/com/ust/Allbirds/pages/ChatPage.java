package com.ust.Allbirds.pages;

import java.time.Duration;
import java.util.ArrayList;
import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class ChatPage {
	WebDriver driver;

	public ChatPage(WebDriver driver) {
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	@FindBy(id = "gladlyChat_container")
	public static WebElement chatbutton2;

	@FindBy(className = "dKAVoA")
	public static WebElement chatsearch;

	@FindBy(className = "fsOmjr")
	public static WebElement resultqueries;

	@FindBy(xpath = "//div[@class='GladlyChat-eJGGJA chLuaf']/span")
	public static WebElement verifychatwindow;

	//@FindBy(className = "cfETjl")
	@FindBy(className = "ijaESO")
	public static WebElement verifysearcherror;

	// @FindBy(className = "cfETjl")
	//public static WebElement repavailable;

	@FindBy(id = "gladlyStartChatButton")
	public static WebElement repnotavailable;

	@FindBy(id = "closeButtonTitleId")
	public static WebElement closechatbutton;

	@FindBy(xpath = "//div[@class='jsx-2022988330 Icon Icon--HELP jsx-3907305029 jsx-85518033']")
	public static WebElement helpicon;

	public void clickChatButton() {
		WebDriverWait wait = new WebDriverWait(driver, Duration.ofSeconds(20));
		wait.until((ExpectedConditions.visibilityOf(ChatPage.chatbutton2)));
		chatbutton2.click();
	}

	public void searchChat(String query) {
		chatsearch.sendKeys(query);
	}

	public String verifyChatWindowMsg() {
		String str = verifychatwindow.getText();
		return str;
	}

	public String verifyQueryResult() {
		List<WebElement> elements = driver.findElements(By.className("fsOmjr"));
		ArrayList<String> arrayList = new ArrayList<>();
		for (WebElement element : elements) {
			arrayList.add(element.getText().toLowerCase());
		}
		String str = "";
		for (int i = 0; i < Math.min(arrayList.size(), 3); i++) {
			str += arrayList.get(i) + " ";
		}
		return str;

	}

	public String verifyErrorResult() {
		String errorstr = verifysearcherror.getText();
		return errorstr;
	}

	public String verifyRepavailableorNot() {
		String valiadtestr = repnotavailable.getText();
		return valiadtestr;
	}

	public void closeChat() {
		closechatbutton.click();
	}

}
