package com.ust.Allbirds.testcases;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.WebDriver;
import org.testng.annotations.AfterClass;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.Test;

import com.ust.Allbirds.base.TestSetUp;
import com.ust.Allbirds.pages.CartPage;
import com.ust.Allbirds.pages.HomePage;

public class TestCartPage extends TestSetUp {
	WebDriver driver;
	CartPage cartpage;
	HomePage homepage;

	@BeforeClass
	public void beforeMethod() {
		driver = invokeBrowser();
		openSite();
		cartpage = new CartPage(driver);
		//driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(10));
		timedelay(3000);
		homepage = new HomePage(driver);
		handlePopUp(HomePage.closepopup);
	}

	@Test(priority = 1)
	public void testAddItemtoCart() {
		
		cartpage.addProductCount();
		if(cartpage.getItemQuantity() > 0 && cartpage.getItemquantity2() > 0)
		assertTrue(true);
	}

	@Test(priority = 2)
	public void testremoveItemfromCart() {
		cartpage.removeProductfromCart();
		if(cartpage.getItemQuantity() > 0 || cartpage.verifyEmptyCart().equals(prop.getProperty("EmptyCartMsg")));
		assertTrue(true);
	}

	@Test(priority = 5)
	public void testcloseCartPage() {
		cartpage.closeCartPage();
		if(cartpage.checkHelpIcon())
		{
			assertFalse(false);
		}
	}

	@Test(priority = 4)
	public void testCheckoutwithProduct() {
		cartpage.checkout();
		if(CartPage.checkoutbutton.isEnabled())
		{
			assertTrue(true);		}
	}

	@Test(priority = 3)
	public void testCheckoutwithoutProduct() {
		cartpage.removeProductfromCart();
		if(cartpage.verifyEmptyCart().equals(prop.getProperty("EmptyCartMsg")))
		{
			assertTrue(true);
		}
	}

	@AfterClass()
	public void AfterMethod() {
		driver.quit();
	}

}
